from django.apps import AppConfig


class AppRssConfig(AppConfig):
    name = 'app_rss'
