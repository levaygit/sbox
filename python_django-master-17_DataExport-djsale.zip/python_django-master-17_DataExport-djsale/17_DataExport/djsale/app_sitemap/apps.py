from django.apps import AppConfig


class AppSitemapConfig(AppConfig):
    name = 'app_sitemap'
